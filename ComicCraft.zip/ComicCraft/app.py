"""
ComicCraft - AI Comic Story Creator
Powered by Google Gemini (story: gemini-2.5-flash, art: gemini-2.5-flash-image)
Naan Mudhalvan / TN Skills Project
"""
import io
import json
import os
import textwrap
import zipfile

import streamlit as st
from dotenv import load_dotenv
from google import genai
from google.genai import types
from PIL import Image, ImageDraw, ImageFont

load_dotenv()

TEXT_MODEL = "gemini-2.5-flash"
IMAGE_MODEL = "gemini-2.5-flash-image"

STYLES = [
    "Classic American superhero comic",
    "Japanese manga (black & white)",
    "Cartoon / Saturday morning",
    "Watercolor storybook",
    "Retro pop-art",
    "Tamil folk-art inspired",
]
GENRES = ["Adventure", "Comedy", "Sci-Fi", "Mystery", "Fantasy", "Moral story for kids", "Historical"]


# ---------------------------------------------------------------- Gemini helpers
def get_client(api_key: str) -> genai.Client:
    return genai.Client(api_key=api_key)


def generate_script(client, idea, genre, style, panels, language):
    """Ask Gemini for a structured comic script (JSON)."""
    prompt = f"""
You are a professional comic book writer. Create a {panels}-panel comic script.

Story idea: {idea}
Genre: {genre}
Art style: {style}
Dialogue/caption language: {language}

Return ONLY valid JSON in this exact format:
{{
  "title": "comic title",
  "character_sheet": "detailed, consistent visual description of every main character (age, hair, clothes, colours, features)",
  "panels": [
    {{
      "number": 1,
      "scene": "what the artist should draw: setting, characters, action, camera angle, mood",
      "caption": "short narration text (or empty string)",
      "dialogue": "Character: line (or empty string)"
    }}
  ]
}}
Keep dialogue short so it fits in a speech bubble. The story must have a clear beginning, middle and end.
"""
    resp = client.models.generate_content(
        model=TEXT_MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0.9),
    )
    return json.loads(resp.text)


def generate_panel_image(client, panel, character_sheet, style):
    """Generate one comic panel image. Returns PIL.Image or None."""
    prompt = f"""
Draw a single comic book panel in this style: {style}.
Characters (keep them EXACTLY consistent): {character_sheet}
Scene: {panel['scene']}
Do not include any text, speech bubbles or captions in the image. Landscape composition, bold clean outlines.
"""
    resp = client.models.generate_content(
        model=IMAGE_MODEL,
        contents=[prompt],
        config=types.GenerateContentConfig(response_modalities=["IMAGE"]),
    )
    for part in resp.candidates[0].content.parts:
        if getattr(part, "inline_data", None) and part.inline_data.data:
            return Image.open(io.BytesIO(part.inline_data.data)).convert("RGB")
    return None


# ---------------------------------------------------------------- Export helpers
def compose_panel(img: Image.Image, panel: dict, width=800) -> Image.Image:
    """Panel image + caption/dialogue strip underneath."""
    ratio = width / img.width
    img = img.resize((width, int(img.height * ratio)))
    try:
        font = ImageFont.load_default(size=20)
    except TypeError:  # older Pillow
        font = ImageFont.load_default()

    lines = []
    for key in ("caption", "dialogue"):
        text = panel.get(key, "").strip()
        if text:
            lines += textwrap.wrap(text, width=70) + [""]
    strip_h = max(40, 28 * len(lines) + 20)

    canvas = Image.new("RGB", (width, img.height + strip_h), "white")
    canvas.paste(img, (0, 0))
    draw = ImageDraw.Draw(canvas)
    draw.rectangle([0, 0, width - 1, canvas.height - 1], outline="black", width=4)
    y = img.height + 10
    for line in lines:
        draw.text((14, y), line, fill="black", font=font)
        y += 28
    return canvas


def build_pdf(title, composed):
    buf = io.BytesIO()
    composed[0].save(buf, format="PDF", save_all=True, append_images=composed[1:], title=title)
    return buf.getvalue()


def build_zip(script, images):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("script.json", json.dumps(script, indent=2, ensure_ascii=False))
        for i, img in enumerate(images, 1):
            b = io.BytesIO()
            img.save(b, format="PNG")
            z.writestr(f"panel_{i}.png", b.getvalue())
    return buf.getvalue()


# ---------------------------------------------------------------- UI
st.set_page_config(page_title="ComicCraft", page_icon="🎨", layout="wide")
st.title("🎨 ComicCraft – AI Comic Story Creator")
st.caption("Turn a story idea into a illustrated comic using Google Gemini.")

with st.sidebar:
    st.header("⚙️ Settings")
    api_key = st.text_input("Gemini API Key", type="password", value=os.getenv("GEMINI_API_KEY", ""),
                            help="Get a free key at https://aistudio.google.com/apikey")
    style = st.selectbox("Art style", STYLES)
    genre = st.selectbox("Genre", GENRES)
    language = st.selectbox("Language", ["English", "Tamil", "Hindi", "Telugu", "Malayalam"])
    panels_n = st.slider("Number of panels", 3, 8, 4)

idea = st.text_area("📝 Your story idea",
                    placeholder="A young girl from Coimbatore builds a robot to help farmers save their crops...",
                    height=120)

if st.button("✨ Create Comic", type="primary", use_container_width=True):
    if not api_key:
        st.error("Please enter your Gemini API key in the sidebar.")
        st.stop()
    if not idea.strip():
        st.warning("Please write a story idea first.")
        st.stop()

    client = get_client(api_key)
    try:
        with st.spinner("Writing the script..."):
            script = generate_script(client, idea, genre, style, panels_n, language)

        images, progress = [], st.progress(0.0, text="Drawing panels...")
        for i, panel in enumerate(script["panels"]):
            img = generate_panel_image(client, panel, script["character_sheet"], style)
            if img is None:
                img = Image.new("RGB", (800, 450), "lightgray")
            images.append(img)
            progress.progress((i + 1) / len(script["panels"]), text=f"Drew panel {i + 1}/{len(script['panels'])}")
        progress.empty()
        st.session_state["comic"] = {"script": script, "images": images}
    except Exception as e:
        st.error(f"Something went wrong: {e}")

comic = st.session_state.get("comic")
if comic:
    script, images = comic["script"], comic["images"]
    st.header(script["title"])
    with st.expander("Character sheet"):
        st.write(script["character_sheet"])

    composed = [compose_panel(img, p) for img, p in zip(images, script["panels"])]
    cols = st.columns(2)
    for i, (c, p) in enumerate(zip(composed, script["panels"])):
        cols[i % 2].image(c, caption=f"Panel {p['number']}", use_container_width=True)

    d1, d2 = st.columns(2)
    d1.download_button("⬇️ Download PDF", build_pdf(script["title"], composed),
                       file_name="comic.pdf", mime="application/pdf", use_container_width=True)
    d2.download_button("⬇️ Download panels (ZIP)", build_zip(script, images),
                       file_name="comic_panels.zip", mime="application/zip", use_container_width=True)
